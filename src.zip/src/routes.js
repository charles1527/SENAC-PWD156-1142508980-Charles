import {BrowserRouter,Routes,Route}from'react-router-dom'
import Home from './pages/Home'
import Cad from './pages/Cadastro de Cliente'
import ContaCorrente from'./pages/Movimentacao da Conta Corrente'
import Financiamento from'./pages/Simulacao de Financiamento'
import Sobre from'./pages/Sobre Nos'

function RoutesApp(){
    return(
        <BrowserRouter>
        <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/Cadastro' element={<Cad/>}/>
            <Route path='/ContaCorrente' element={<ContaCorrente/>}/>
            <Route path='/Financiamento' element={<Financiamento/>}/>
            <Route path='/Sobre' element={<Sobre/>}/>
        </Routes>
            
            </BrowserRouter>


    );
}
export default RoutesApp;