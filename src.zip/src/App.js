/** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
2 * SENAC - TADS - Programacao Web *
3 * ADO #02 Trabalhando As Rotas e LINKS *
4 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
5 * Nome : << Charles Aparecido da Silva Moreira > > *
6 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
import RoutesApp from './routes';

function App() {
  return (
    <RoutesApp/>
  );
}

export default App;
