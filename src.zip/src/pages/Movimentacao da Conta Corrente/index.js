import {Link} from'react-router-dom';
function ContaCorrente(){
    return(
        <div>
            <h1>Conta Corrente</h1>
            <Link to= '/'>Home</Link><br/>
            <Link to= '/Cadastro'>Cadastro Cliente</Link><br/>
            <Link to= '/Financiamento'>Financiamento</Link><br/>
            <Link to= '/Sobre'>Sobre Nós</Link><br/>
        </div>
    );
}
export default ContaCorrente;