import {Link} from 'react-router-dom';
function Home(){
    return(
        <div>
            <h1>Pagina Home</h1>
            <Link to= '/Cadastro'>Cadastro Cliente</Link><br/>
            <Link to= '/ContaCorrente'>Conta Corrente</Link><br/>
            <Link to= '/Financiamento'>Financiamento</Link><br/>
            <Link to= '/Sobre'>Sobre Nós</Link><br/>
        </div>
    );
}

export default Home;