import {Link} from'react-router-dom';
function Sobre(){
    return(
        <div>
            <h1>Sobre Nós</h1>
            <Link to= '/'>Home</Link><br/>
            <Link to= '/Cadastro'>Cadastro Cliente</Link><br/>
            <Link to= '/ContaCorrente'>Conta Corrente</Link><br/>
            <Link to= '/Financiamento'>Financiamento</Link><br/>
        </div>
    );
}
export default Sobre;