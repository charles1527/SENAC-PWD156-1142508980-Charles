import {Link} from'react-router-dom';
function Financiamento(){
    return(
        <div>
            <h1> Financiamento </h1>
            <Link to= '/'>Home</Link><br/>
            <Link to= '/Cadastro'>Cadastro Cliente</Link><br/>
            <Link to= '/ContaCorrente'>Conta Corrente</Link><br/>
            <Link to= '/Sobre'>Sobre Nós</Link><br/>
        </div>
    );
}
export default Financiamento;