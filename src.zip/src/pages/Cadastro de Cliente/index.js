import {Link} from 'react-router-dom';
function Cad(){
    return(
        <div>
            <h1>Pagina de Cadastro</h1>
            <Link to= '/'>Home</Link><br/>
            <Link to= '/ContaCorrente'>Conta Corrente</Link><br/>
            <Link to= '/Financiamento'>Financiamento</Link><br/>
            <Link to= '/Sobre'>Sobre Nós</Link><br/>
        </div>
    );
}
export default Cad;